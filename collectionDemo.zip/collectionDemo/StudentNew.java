package collectionDemo;

public class StudentNew 
{
	public int age;
	public String name;
	public int roll;
	
	public StudentNew(int age, String name, int roll) {
		super();
		this.age = age;
		this.name = name;
		this.roll = roll;
	}
	
}
