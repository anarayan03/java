package collectionDemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class SortingDemo2 
{
	public static void main(String[] args) {
		ArrayList<StudentNew> s1 = new ArrayList<StudentNew>();
		s1.add(new StudentNew(23, "Xevior", 166157));
		s1.add(new StudentNew(21, "Prithvi", 166174));
		s1.add(new StudentNew(18, "Aditya", 166177));
		s1.add(new StudentNew(28, "Shubham", 166170));
		/*for(Student a1:s1)
		{
			System.out.println(a1.age);
		}
		System.out.println("After sorting");
		Collections.sort(s1);
		for(Student a1:s1)
		{
			System.out.println(a1.age);
		}*/
		NameComparator nc = new NameComparator();
		Collections.sort(s1,nc);
		Iterator<StudentNew> iterator = s1.iterator();
		while(iterator.hasNext())
		{
			StudentNew stu = iterator.next();	
		System.out.println(stu.name);
			
		}
	}
}
