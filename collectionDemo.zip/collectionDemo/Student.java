package collectionDemo;

public class Student implements Comparable<Student>
{
	public int age;
	public String name;
	public int roll;
	
	public Student(int age, String name, int roll) {
		super();
		this.age = age;
		this.name = name;
		this.roll = roll;
	}

	@Override
	public int compareTo(Student o) {
		if(age==o.age)
			return 0;
		else if(age>o.age)
			return 1;
		else
			return -1;
	}
	
	
}
