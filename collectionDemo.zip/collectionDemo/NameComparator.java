package collectionDemo;

import java.util.Comparator;

public class NameComparator implements Comparator
{

	@Override
	public int compare(Object o1, Object o2) 
	{
		StudentNew sn1=(StudentNew) o1;
		StudentNew sn2=(StudentNew) o2;
		return sn1.name.compareTo(sn2.name);
	}

	
	
}
