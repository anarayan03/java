package collectionDemo;

public class newCl {
	public static void main(String[] args) {
		
		try
		{
			return;
		}
		finally
		{
			System.out.println("str");
		}
	}

}
