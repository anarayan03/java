package collectionDemo;

import java.util.ArrayList;
import java.util.Collections;

public class SortingDemo 
{
	public static void main(String[] args) {
		ArrayList<Student> s1 = new ArrayList<Student>();
		s1.add(new Student(23, "Aditya", 166157));
		s1.add(new Student(21, "Prithvi", 166174));
		s1.add(new Student(18, "Sohan", 166177));
		s1.add(new Student(28, "Shubham", 166170));
		for(Student a1:s1)
		{
			System.out.println(a1.age);
		}
		System.out.println("After sorting");
		Collections.sort(s1);
		for(Student a1:s1)
		{
			System.out.println(a1.age);
		}
	}
}
