//6.2
package exception;

public class AgeException extends Exception
{

	public AgeException(String str)
	{
		System.out.println(str);
	}
	
}
