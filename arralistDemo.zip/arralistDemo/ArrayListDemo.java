package arralistDemo;

import java.util.ArrayList;

public class ArrayListDemo
{
	public static void main(String[] args) {
		ArrayList arrayList = new ArrayList<>();
		arrayList.add("Pen");
		arrayList.add("pencil");
		arrayList.add("ereaser");
		arrayList.add("sharpner");
		arrayList.add("scale");
		arrayList.add("protector");
		arrayList.add(23);
		System.out.println(arrayList);
		arrayList.remove(0);
		System.out.println(arrayList);
		arrayList.remove(3);
		System.out.println(arrayList);
	}
}
