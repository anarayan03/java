package arrayDemo;

import java.lang.reflect.Array;
import java.util.Arrays;

public class ArrayClass
{

	public static void main(String[] args)
	{
		int arr[]=new int[] {3,1,7,9,5,2};
		/*for(int var:arr)
		{
			System.out.print(var+" ");
		}*/
		//System.out.println("\n"+Arrays.binarySearch(arr, 10));
		Arrays.sort(arr,0,3);
		for(int var2:arr)
		{
			System.out.println(var2);
		}
		/*int arr1[]=Arrays.copyOf(arr, 3);
		for(int var2:arr1)
		{
			System.out.println(var2);
		}*/
		/*int arr2[]=Arrays.copyOfRange(arr, 0,4);
		for(int var3:arr2)
		{
			System.out.println(var3);
		}*/
	}

}
