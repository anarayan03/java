package arrayDemo;

public class EmployeeMain 
{
	public static void main(String[] args)
	{
		EmployeeArray ea[]=new EmployeeArray[3];
		ea[0] = new EmployeeArray(166157, "Aditya", 17000);
		ea[1] = new EmployeeArray(166158, "Prithvi", 17000);
		ea[2] = new EmployeeArray(166159, "Sohan", 17000);
		for(int i=0;i<ea.length;i++)
		{
			System.out.println(ea[i].empId+" "+ea[i].empName+" "+ea[i].salary);
		}
	}
}
