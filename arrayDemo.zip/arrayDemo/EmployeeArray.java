package arrayDemo;

public class EmployeeArray
{
	public int empId;
	public String empName;
	public long salary;
	
	public EmployeeArray(int empId, String empName, long salary) 
	{
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
	}
	
}
